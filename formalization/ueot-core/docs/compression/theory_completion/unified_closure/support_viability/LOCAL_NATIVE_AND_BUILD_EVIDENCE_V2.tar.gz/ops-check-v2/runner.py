from pathlib import Path
import subprocess,hashlib,json,time,datetime
repo=Path('/Users/murphyhoops/Documents/ueotlean-worktrees/support-policy-20261020')
out=Path('/Users/murphyhoops/Documents/ueotlean-worktrees/support-viability-local-20261020/ops-check-v2')
manifest=json.loads((out/'source-manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def intact():return all(sha(repo/x['path'])==x['sha256'] for x in manifest['source_files'])
state={'state':'RUNNING','source_manifest_sha256':sha(out/'source-manifest.json'),'results':[],'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(): (out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
commands=[
('diff',['git','diff','--check']),
('policy',['python3','-B','formalization/ueot-core/scripts/validate_compression_research.py','--repo-root','.','--baseline-ref','7b1f7c3cf2e86cb85dcdb1b4618c247c517407f8','--branch-name','ops/compression-local-build-support-evidence','--head-repo','MurphyHoops/UEOT','--base-repo','MurphyHoops/UEOT']),
('research_tests',['python3','-B','formalization/ueot-core/scripts/test_validate_compression_research.py','--repo-root','.']),
('compression_tests',['python3','-B','formalization/ueot-core/scripts/test_validate_compression.py','--repo-root','.']),
('finalization_tests',['python3','-B','formalization/ueot-core/scripts/test_validate_finalization_receipt.py'])]
assert intact()
save()
for label,command in commands:
 started=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 state['results'].append({'label':label,'command':command,'returncode':r.returncode,'seconds':round(time.monotonic()-started,3),'log_sha256':sha(out/(label+'.log'))});save()
 if r.returncode:state['state']='FAIL';break
else:state['state']='PASS'
state['source_intact_after']=intact()
if not state['source_intact_after']:state['state']='FAIL_SOURCE_CHANGED'
state['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
