from pathlib import Path
import json,os,subprocess,hashlib,time,datetime
out=Path(__file__).parent
repo=Path('/Users/murphyhoops/Documents/ueotlean-worktrees/support-viability-core-20261020')
manifest=json.loads((out/'PRODUCTION_SOURCE_MANIFEST_V3.json').read_text())
env=dict(os.environ);env['PATH']=str(Path.home()/'.elan/bin')+':/opt/homebrew/bin:/usr/local/bin:'+env.get('PATH','');env['PYTHONDONTWRITEBYTECODE']='1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 for x in manifest['files']:assert sha(repo/x['path'])==x['sha256'],x['path']
state={'state':'RUNNING','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_head_context':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_manifest_sha256':sha(out/'PRODUCTION_SOURCE_MANIFEST_V3.json'),'results':[]}
def save():(out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
modules=[x['path'][len('formalization/ueot-core/'):-5].replace('/','.') for x in manifest['files'] if not x['path'].endswith('/TheoryCompletion.lean')]
try:
 verify()
 for label,command in [('nine_modules',['lake','build',*modules]),('full_ueot',['lake','build','UEOT'])]:
  state['active']=label;save();log=out/(label+'.log');start=time.monotonic()
  with log.open('xb') as f:r=subprocess.run(command,cwd=repo/'formalization/ueot-core',env=env,stdout=f,stderr=subprocess.STDOUT)
  state['results'].append({'label':label,'command':command,'returncode':r.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'log_sha256':sha(log)})
  verify();save()
  if r.returncode:raise RuntimeError(label+' failed; inspect actual log')
 state.pop('active',None);state['state']='PASS'
except Exception as e:state.update(state='FAIL',error=str(e))
state['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state),flush=True)

if state['state']=='PASS':
 native=out.parent/'native-observed-v2';final=out.parent/'native-final-v2'
 common=['--repo',str(repo),'--build-status',str(out/'status.json'),'--build-manifest',str(out/'PRODUCTION_SOURCE_MANIFEST_V3.json'),'--build-log-dir',str(out),'--focused-label','nine_modules','--full-label','full_ueot','--base-ref','7b1f7c3cf2e86cb85dcdb1b4618c247c517407f8']
 chain={'state':'RUNNING','steps':[]}
 def chain_save():(out/'continuation-status.json').write_text(json.dumps(chain,indent=2)+'\n')
 chain_save()
 for label,command in [
  ('native',['python3','-B',str(out.parent/'native-preparation/run_native_support_viability_pipeline.py'),'--output',str(native),*common]),
  ('finalize',['python3','-B',str(out.parent/'native-preparation/finalize_observed_support_viability_overlay.py'),'--observed',str(native),'--output',str(final),*common])]:
  with (out/(label+'-continuation.log')).open('xb') as f:q=subprocess.run(command,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
  chain['steps'].append({'label':label,'returncode':q.returncode,'log_sha256':sha(out/(label+'-continuation.log'))});chain_save()
  if q.returncode:chain['state']='FAIL';break
 else:chain['state']='PASS'
 chain_save()
