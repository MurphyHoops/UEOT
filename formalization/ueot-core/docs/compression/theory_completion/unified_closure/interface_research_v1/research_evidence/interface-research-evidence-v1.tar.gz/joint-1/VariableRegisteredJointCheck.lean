import UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.RegisteredDeploymentRisk
import UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.DeploymentCoverage
import UEOT.V3.HilbertMeanProductBlockIndependence

/-!
Research module outside the production import graph.
Actual validation status is recorded separately in the accompanying build receipt.

This draft changes the registered row sample count from one common N to a
fixed positive N j. It reuses the existing registered calibration theorem
on each singleton row; no new concentration inequality is assumed.
-/

namespace UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.VariableRegisteredSamples

open MeasureTheory ProbabilityTheory
open UEOT.V3.TotalVariation
open UEOT.V3.HilbertMeanProductBlockIndependence
open scoped BigOperators Classical

noncomputable section

universe uJ uX uΩ

/-- The complete registration and its sample allocation are fixed before data. -/
abbrev SampleCoordinate {J : Type uJ} (N : J → ℕ) := Σ j, Fin (N j)

/-- A real product experiment has exactly the allocated coordinates. -/
def productRowLaw
    {J : Type uJ} {X : Type uX} [Fintype J] [MeasurableSpace X]
    (row : J → PMF X) (N : J → ℕ) :
    Measure (SampleCoordinate N → X) :=
  Measure.pi (fun jk : SampleCoordinate N => (row jk.1).toMeasure)

instance productRowLaw_isProbability
    {J : Type uJ} {X : Type uX} [Fintype J] [MeasurableSpace X]
    (row : J → PMF X) (N : J → ℕ) :
    IsProbabilityMeasure (productRowLaw row N) := by
  unfold productRowLaw
  infer_instance

def productRowSample
    {J : Type uJ} {X : Type uX} {N : J → ℕ}
    (j : J) (k : Fin (N j)) (ω : SampleCoordinate N → X) : X :=
  ω ⟨j, k⟩

theorem productRowSample_measurable
    {J : Type uJ} {X : Type uX} [MeasurableSpace X] {N : J → ℕ}
    (j : J) (k : Fin (N j)) :
    Measurable (productRowSample (X := X) j k) :=
  measurable_pi_apply (⟨j, k⟩ : SampleCoordinate N)

theorem productRowSample_law
    {J : Type uJ} {X : Type uX} [Fintype J] [MeasurableSpace X]
    (row : J → PMF X) (N : J → ℕ) (j : J) (k : Fin (N j)) :
    (productRowLaw row N).map (productRowSample j k) = (row j).toMeasure := by
  exact (measurePreserving_eval
    (fun jk : SampleCoordinate N => (row jk.1).toMeasure) ⟨j, k⟩).map_eq

theorem productRowSample_independent
    {J : Type uJ} {X : Type uX} [Fintype J] [MeasurableSpace X]
    (row : J → PMF X) (N : J → ℕ) (j : J) :
    iIndepFun (productRowSample (X := X) (N := N) j) (productRowLaw row N) := by
  have hall := coordinate_iIndep
    (fun jk : SampleCoordinate N => (row jk.1).toMeasure)
  exact iIndepFun.precomp
    (g := fun k : Fin (N j) => (⟨j, k⟩ : SampleCoordinate N))
    (by intro k l h; simpa using h) hall

/-- Allocation-sensitive confidence budget; no minimum-count replacement. -/
def confidenceBudget
    {J : Type uJ} (X : Type uX) [Fintype X] [Fintype J]
    (N : J → ℕ) (rho : J → ℝ) : ℝ :=
  ∑ j, (Fintype.card (Finset X) : ℝ) *
    (2 * Real.exp (-2 * (N j : ℝ) * (rho j) ^ 2))

/-- Existing single-row calibration is reused for each registration.
The intersection uses only a union bound, so rows may share dependent data.
All sample counts and radii are deterministic inputs, independent of ω. -/
theorem registered_row_calibration
    {Ω : Type uΩ} {X : Type uX} {J : Type uJ}
    [MeasurableSpace Ω] [MeasurableSpace X] [MeasurableSingletonClass X]
    [Fintype X] [Fintype J]
    (N : J → ℕ) (hN : ∀ j, 0 < N j)
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    (row : J → PMF X) (sample : ∀ j, Fin (N j) → Ω → X) (rho : J → ℝ)
    (hmeas : ∀ j k, Measurable (sample j k))
    (hindep : ∀ j, iIndepFun (sample j) μ)
    (hlaw : ∀ j k, μ.map (sample j k) = (row j).toMeasure)
    (hrho : ∀ j, 0 ≤ rho j) :
    ∃ good : Set Ω, MeasurableSet good ∧
      μ.real goodᶜ ≤ confidenceBudget X N rho ∧
      ∀ ω ∈ good, ∀ j,
        tvDist (row j).toMeasure
          (empiricalResponsePMF (hN j) (sample j) ω).toMeasure ≤ rho j := by
  have hrow : ∀ j, ∃ good : Set Ω, MeasurableSet good ∧
      μ.real goodᶜ ≤ (Fintype.card (Finset X) : ℝ) *
        (2 * Real.exp (-2 * (N j : ℝ) * (rho j) ^ 2)) ∧
      ∀ ω ∈ good,
        tvDist (row j).toMeasure
          (empiricalResponsePMF (hN j) (sample j) ω).toMeasure ≤ rho j := by
    intro j
    obtain ⟨good, hg, hb, hc⟩ := coverage_registered_row_calibration (hN j) μ
      (fun _ : Unit => row j) (fun _ : Unit => sample j) (fun _ : Unit => rho j)
      (fun _ => hmeas j) (fun _ => hindep j) (fun _ => hlaw j) (fun _ => hrho j)
    exact ⟨good, hg, by simpa using hb, fun ω hω => hc ω hω ()⟩
  choose good hgood hbad hcal using hrow
  refine ⟨⋂ j, good j, MeasurableSet.iInter hgood, ?_, ?_⟩
  · have hcompl : (⋂ j, good j)ᶜ = ⋃ j, (good j)ᶜ := by
      ext ω
      simp
    rw [hcompl]
    exact (measureReal_iUnion_fintype_le _).trans
      (Finset.sum_le_sum fun j _ => hbad j)
  · intro ω hω j
    exact hcal j ω (Set.mem_iInter.mp hω j)

/-- Real coordinate laws discharge every sampling premise of calibration. -/
theorem product_experiment_calibration
    {J : Type uJ} {X : Type uX}
    [Fintype J] [Fintype X] [MeasurableSpace X] [MeasurableSingletonClass X]
    (row : J → PMF X) (N : J → ℕ) (hN : ∀ j, 0 < N j)
    (rho : J → ℝ) (hrho : ∀ j, 0 ≤ rho j) :
    ∃ good : Set (SampleCoordinate N → X), MeasurableSet good ∧
      (productRowLaw row N).real goodᶜ ≤ confidenceBudget X N rho ∧
      ∀ ω ∈ good, ∀ j,
        tvDist (row j).toMeasure
          (empiricalResponsePMF (hN j) (productRowSample j) ω).toMeasure ≤ rho j := by
  exact registered_row_calibration N hN (productRowLaw row N) row productRowSample rho
    productRowSample_measurable (productRowSample_independent row N)
    (productRowSample_law row N) hrho

end
end UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.VariableRegisteredSamples

-- Kernel axiom closure of the real experiment and joint calibration.
#print axioms UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.VariableRegisteredSamples.product_experiment_calibration
#print axioms UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.VariableRegisteredSamples.registered_row_calibration

/-!
Research adapter tail outside the production import graph.
Actual validation status is recorded separately in the accompanying build receipt.

For one focused combined check, prepend the published import
  import UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.RegisteredDeploymentRisk
then include the already validated VariableRegisteredSamples prototype,
then append this file. This file intentionally has no import, so it does not
require installing an uncommitted prototype .olean in the production tree.

Fixed unequal registered-row sample counts feed the actual selected source
risk through the existing sampling-free coverage endpoint. The established
training/deployment joint lemma performs the entire good/bad mixture step.
-/

namespace UEOT.V3.Compression.TheoryCompletion.UnifiedClosure
namespace VariableRegisteredJointCheck

open MeasureTheory ProbabilityTheory UEOT.V3.PathError UEOT.V3.TotalVariation
open scoped BigOperators Classical

noncomputable section

universe uΩ uC u

/-- The same source rows are calibrated before selection, with fixed per-row
sample allocations. The event is the canonical simultaneous source-to-empirical
TV condition, not a new asserted probability estimate. -/
def RegisteredCalibrationGood
    {Ω : Type uΩ} {X A : Type u} [MeasurableSpace X]
    (P : ℕ → X → A → PMF X) (certified : ℕ → X → A → Prop) (T : ℕ)
    (N : CoverageRegisteredRow certified T → ℕ) (hN : ∀ j, 0 < N j)
    (sample : ∀ j : CoverageRegisteredRow certified T, Fin (N j) → Ω → X)
    (rho : ℕ → ℝ) (ω : Ω) : Prop :=
  ∀ j : CoverageRegisteredRow certified T,
    tvDist (P j.1.1 j.1.2.2 j.1.2.1).toMeasure
      (empiricalResponsePMF (hN j) (sample j) ω).toMeasure ≤ rho j.1.1

/-- Specialize the established variable-row confidence budget to the exact
registered source rows; no maximum/minimum sample-count replacement. -/
def registeredConfidenceBudget
    {X A : Type u} [Fintype X] [Fintype A]
    (certified : ℕ → X → A → Prop) (T : ℕ)
    (N : CoverageRegisteredRow certified T → ℕ) (rho : ℕ → ℝ) : ℝ :=
  VariableRegisteredSamples.confidenceBudget X N (fun j => rho j.1.1)

/-- The variable-row calibration event is contained in the canonical TV
event; the latter inherits the same actual training failure budget. -/
theorem registered_calibration_good_bad_le
    {Ω : Type uΩ} {X A : Type u}
    [Fintype Ω] [Fintype X] [Fintype A]
    [MeasurableSpace Ω] [MeasurableSingletonClass Ω]
    [MeasurableSpace X] [MeasurableSingletonClass X]
    (training : Measure Ω) [IsProbabilityMeasure training]
    (P : ℕ → X → A → PMF X) (certified : ℕ → X → A → Prop) (T : ℕ)
    (N : CoverageRegisteredRow certified T → ℕ) (hN : ∀ j, 0 < N j)
    (sample : ∀ j : CoverageRegisteredRow certified T, Fin (N j) → Ω → X)
    (rho : ℕ → ℝ)
    (hmeas : ∀ j k, Measurable (sample j k))
    (hindep : ∀ j, iIndepFun (sample j) training)
    (hlaw : ∀ j k, training.map (sample j k) =
      (P j.1.1 j.1.2.2 j.1.2.1).toMeasure)
    (hrho : ∀ n, n < T → 0 ≤ rho n) :
    MeasurableSet {ω | RegisteredCalibrationGood P certified T N hN sample rho ω} ∧
      training.real {ω | ¬ RegisteredCalibrationGood P certified T N hN sample rho ω} ≤
        registeredConfidenceBudget certified T N rho := by
  obtain ⟨good, _hgood, hbad, hcal⟩ :=
    VariableRegisteredSamples.registered_row_calibration N hN training
      (fun j : CoverageRegisteredRow certified T => P j.1.1 j.1.2.2 j.1.2.1)
      sample (fun j => rho j.1.1) hmeas hindep hlaw
      (fun j => hrho j.1.1 j.1.1.isLt)
  refine ⟨Set.to_countable _ |>.measurableSet, ?_⟩
  have hsub :
      {ω | ¬ RegisteredCalibrationGood P certified T N hN sample rho ω} ⊆ goodᶜ := by
    intro ω hω hg
    exact hω (hcal ω hg)
  exact (measureReal_mono hsub).trans hbad

/-- Unequal fixed sample allocations, selected empirical fits, and actual
selected-policy occupancy caps yield the same sharp joint mixture budget.

All fit, occupancy, envelope and numerical checks concern the SAME Good
event. The microscopic event E, actual source P, registration and N are
fixed before sampling. The proof creates the true row TV estimates locally
and uses the existing sampling-free source-risk endpoint, then the existing
selectedTrainingDeployment_failure_le. No calibration or joint probability
bound is included as a caller hypothesis. -/
theorem registered_selected_joint_failure_of_cap_on_good
    {Ω : Type uΩ} {C : Type uC} {X Y A : Type u}
    [Fintype Ω] [Fintype X] [Fintype Y] [Fintype A]
    [MeasurableSpace Ω] [MeasurableSingletonClass Ω] [MeasurableSpace C]
    [MeasurableSpace X] [MeasurableSingletonClass X]
    [MeasurableSpace Y] [MeasurableSingletonClass Y]
    [MeasurableSpace A] [MeasurableSingletonClass A]
    (training : Measure Ω) [IsProbabilityMeasure training]
    (P : ℕ → X → A → PMF X)
    (certified : ℕ → X → A → Prop) (T : ℕ)
    (N : CoverageRegisteredRow certified T → ℕ) (hN : ∀ j, 0 < N j)
    (sample : ∀ j : CoverageRegisteredRow certified T, Fin (N j) → Ω → X)
    (rho : ℕ → ℝ)
    (hmeas : ∀ j k, Measurable (sample j k))
    (hindep : ∀ j, iIndepFun (sample j) training)
    (hlaw : ∀ j k, training.map (sample j k) =
      (P j.1.1 j.1.2.2 j.1.2.1).toMeasure)
    (hrho : ∀ n, n < T → 0 ≤ rho n)
    (select : Ω → C) (q : C → X → Y) (initial : C → PMF X)
    (Q : C → ℕ → Y → A → PMF Y)
    (policy : C → ∀ n, CausalHistory Y (A × Y) n → PMF A)
    (eta kappa : Ω → ℕ → ℝ)
    (hfit : ∀ ω, RegisteredCalibrationGood P certified T N hN sample rho ω →
      ∀ n (hn : n < T) x a (hc : certified n x a),
      tvDist ((empiricalResponsePMF
        (hN ⟨(⟨n, hn⟩, a, x), hc⟩)
        (sample ⟨(⟨n, hn⟩, a, x), hc⟩) ω).map
          (q (select ω))).toMeasure
        (Q (select ω) n (q (select ω) x) a).toMeasure ≤ eta ω n)
    (hcap : ∀ ω, RegisteredCalibrationGood P certified T N hN sample rho ω →
      ∀ n, n < T →
      (coverageDeploymentRowLaw (initial (select ω)) (q (select ω)) P
        (policy (select ω)) n).toMeasure.real {xa | ¬ certified n xa.1 xa.2} ≤ kappa ω n)
    (E : Set (CausalHistory X (A × X) T))
    (F : C → Set (CausalHistory Y (A × Y) T))
    (henvelope : ∀ ω, RegisteredCalibrationGood P certified T N hN sample rho ω →
      E ⊆ (riskHistoryMap (q (select ω))
        (fun ax : A × X => (ax.1, q (select ω) ax.2)) T) ⁻¹' F (select ω))
    (β : ℝ) (hβ : β ∈ Set.Icc (0 : ℝ) 1)
    (hchecked : ∀ ω, RegisteredCalibrationGood P certified T N hN sample rho ω →
      min 1 ((causalLaw ((initial (select ω)).map (q (select ω)))
        (riskMacroControlKernel (Q (select ω)) (policy (select ω))) T).toMeasure.real
          (F (select ω)) +
        ∑ n ∈ Finset.range T, (min 1 (rho n + eta ω n) +
          (1 - min 1 (rho n + eta ω n)) * kappa ω n)) ≤ β) :
    Measurable select ∧
      (selectedTrainingDeployment training.toPMF select
        (fun c => causalLaw (initial c) (riskMicroControlKernel (q c) P (policy c)) T)).toMeasure.real
          {z | z.2 ∈ E} ≤
        min 1 (registeredConfidenceBudget certified T N rho +
          (1 - registeredConfidenceBudget certified T N rho) * β) := by
  obtain ⟨_hgood, hbad⟩ := registered_calibration_good_bad_le training
    P certified T N hN sample rho hmeas hindep hlaw hrho
  refine ⟨measurable_of_finite _, ?_⟩
  apply selectedTrainingDeployment_failure_le training.toPMF select
    (fun c => causalLaw (initial c) (riskMicroControlKernel (q c) P (policy c)) T)
    {ω | RegisteredCalibrationGood P certified T N hN sample rho ω}
    (fun _ => E) _ β hβ
  · rw [Measure.toPMF_toMeasure]
    change training.real
      {ω | ¬ RegisteredCalibrationGood P certified T N hN sample rho ω} ≤ _
    exact hbad
  · intro ω hω
    have hcert : ∀ n, n < T → ∀ x a, certified n x a →
        tvDist ((P n x a).map (q (select ω))).toMeasure
          (Q (select ω) n (q (select ω) x) a).toMeasure ≤ min 1 (rho n + eta ω n) := by
      intro n hn x a hc
      let j : CoverageRegisteredRow certified T := ⟨(⟨n, hn⟩, a, x), hc⟩
      exact empirical_coarse_row_tv (P n x a)
        (empiricalResponsePMF (hN j) (sample j) ω)
        (q (select ω)) (measurable_of_countable _)
        (Q (select ω) n (q (select ω) x) a) (rho n) (eta ω n)
        (hω j) (hfit ω hω n hn x a hc)
    have hrisk := coverage_same_policy_microscopic_failure_risk
      (initial (select ω)) (q (select ω)) P (Q (select ω)) (policy (select ω))
      certified (fun n => min 1 (rho n + eta ω n)) T hcert
      E (F (select ω)) (henvelope ω hω)
    have hbudget :=
      ObservableActionCoverageContinuationCheck.deployment_coverage_budget_le_of_actual_occupancy_cap
        (initial (select ω)) (q (select ω)) P (policy (select ω)) certified
        (fun n => min 1 (rho n + eta ω n)) (kappa ω) T
        (fun _ _ => min_le_left _ _) (hcap ω hω)
    exact hrisk.trans
      ((min_le_min le_rfl (add_le_add le_rfl hbudget)).trans (hchecked ω hω))

end
end VariableRegisteredJointCheck
end UEOT.V3.Compression.TheoryCompletion.UnifiedClosure

#print axioms UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.VariableRegisteredJointCheck.registered_calibration_good_bad_le
#print axioms UEOT.V3.Compression.TheoryCompletion.UnifiedClosure.VariableRegisteredJointCheck.registered_selected_joint_failure_of_cap_on_good
