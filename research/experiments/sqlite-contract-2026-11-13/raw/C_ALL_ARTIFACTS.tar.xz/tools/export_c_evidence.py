#!/usr/bin/env python3
"""Export C's existing evidence only. Does not run any new trial."""
import gzip,hashlib,json,zipfile
from collections import Counter
from pathlib import Path
ROOT=Path("/Users/murphyhoops/Documents/ueot-sqlite-study-20261113")
C=ROOT/"independent-C"
def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj):
    with p.open("x") as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write("\n")
def lines(p):return [json.loads(s) for s in p.read_text().splitlines()]
def summarize(run,check):
    counts=Counter();acks=Counter();totals={}
    for name in ["candidate","strong_baseline","weak_structure","identity_ablation"]:
        totals[name]={"callbacks":0,"returned_rows":0,"canonical_returned_bytes":0,"logical_copy_read_bytes":0,"logical_copy_write_bytes":0,"decisions":dict()}
    unknown=[]
    for item in check["trials"]:
        spec=item["spec"];case=run/spec["run_id"];counts[item["policies"]["candidate"]["observed"]]+=1;acks[item["ack_class_C"]]+=1
        tr=load(case/"trial-result.json")
        for name,fields in totals.items():
            raw=load(case/"policy"/name/"execution/result.json")
            fields["callbacks"]+=raw["callback_count"];fields["returned_rows"]+=raw["rows_returned"]
            fields["canonical_returned_bytes"]+=raw["canonical_returned_bytes"]
            fields["logical_copy_read_bytes"]+=tr["policies"][name]["copy"]["application_copy_read_bytes"]
            fields["logical_copy_write_bytes"]+=tr["policies"][name]["copy"]["application_copy_write_bytes"]
            decision=raw["decision"];fields["decisions"][decision]=fields["decisions"].get(decision,0)+1
        if item["ack_class_C"]=="UNKNOWN":
            ev=lines(case/"parent-events.jsonl")
            commands=[x["message"] for x in ev if x["event"]=="PARENT_SENT" and x["message"]["cmd"]=="TRANSACTION"]
            last=commands[-1];tid=last["request"]["txn_id"]
            msgs=[x["message"] for x in ev if x["event"]=="CHILD_MESSAGE_RECEIVED" and x["message"].get("txn_id")==tid]
            unknown.append({"run_id":spec["run_id"],"last_txn":tid,"pause_precommit":last.get("pause_precommit"),"pause_preack":last.get("pause_preack"),"precommit_progress_received":any(x["event"]=="PRECOMMIT_READY" for x in msgs),"commit_return_received":any(x["event"]=="COMMIT_RETURNED_NO_ACK" for x in msgs),"ack_received":any(x["event"]=="ACK" for x in msgs),"worker_exit":tr["worker_returncode"],"knowledge_C":"UNKNOWN"})
    return {"count":check["planned"],"direct_rehash_file_count":check["raw_files_directly_rehashed"],
            "check_errors":check["global_errors"],"trials_without_check_errors":check["trials_without_check_errors"],
            "candidate_counts":dict(counts),"knowledge_counts":dict(acks),"resource_totals":totals,"unknown_cases":unknown,
            "checker_result_sha256":sha(C/("certification-check-v1.json" if run.name=="run-v1" and run.parent.name=="certification" else "replication-check-v1.json"))}
cert=ROOT/"certification/run-v1";rep=C/"replication/run-v1"
cc=load(C/"certification-check-v1.json");rc=load(C/"replication-check-v1.json")
cd=load(C/"certification-direct-read/C_DIRECT_READ.json");rd=load(C/"replication-direct-read/C_DIRECT_READ.json")
direct_summaries={}
for name,data in [("certification",cd),("replication",rd)]:
    direct_summaries[name]=[{k:v for k,v in row.items() if k not in ["observation","observations"]} for row in data["results"]]
compact={"C_execution_receipt":load(C/"C_EXECUTION_RECEIPT.json"),
         "certification":summarize(cert,cc),"replication":summarize(rep,rc),"direct_reads":direct_summaries}
write(C/"C_FINAL_COMPACT.json",compact)
decisive={"purpose":"Full C-owned decisive reads plus source parent requests and raw messages; preserves same-H pairing",
          "preregistration_commit":"26902c25152ca3676b4844d2156f028145f62fe2",
          "protocol":load(C/"registered-source/protocol.json"),"direct_record":cd,"source_records":{}}
for row in cd["results"]:
    rid=row["run_id"];case=cert/rid
    decisive["source_records"][rid]={"initial":load(case/"oracle/initial.json"),"parent_events":lines(case/"parent-events.jsonl"),
                                    "raw_child_messages":lines(case/"worker.stdout.raw"),"trial_spec":load(case/"oracle/trial_spec.json")}
raw=json.dumps(decisive,ensure_ascii=False,indent=2).encode()+b"\n"
with (C/"C_DECISIVE_CERT_EVIDENCE.json.gz").open("xb") as f:f.write(gzip.compress(raw,mtime=0))
write(C/"C_DECISIVE_CERT_EVIDENCE_MANIFEST.json",{"raw_bytes":len(raw),"raw_sha256":hashlib.sha256(raw).hexdigest(),
  "gzip_bytes":(C/"C_DECISIVE_CERT_EVIDENCE.json.gz").stat().st_size,"gzip_sha256":sha(C/"C_DECISIVE_CERT_EVIDENCE.json.gz"),
  "direct_run_ids":[x["run_id"] for x in cd["results"]]})
records=[]
for path in sorted(C.rglob("*")):
    if path.is_file() and path.name not in ["C_ALL_ARTIFACTS.zip","C_EXPORT_MANIFEST.json"]:
        records.append({"path":str(path.relative_to(C)),"bytes":path.stat().st_size,"sha256":sha(path)})
write(C/"C_EXPORT_MANIFEST.json",{"files":records,"count":len(records),"boundary":"C-generated raw sources, own run, direct reads and copied preregistration; B full run stored separately."})
with zipfile.ZipFile(C/"C_ALL_ARTIFACTS.zip","x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for row in records:z.write(C/row["path"],row["path"])
    z.write(C/"C_EXPORT_MANIFEST.json","C_EXPORT_MANIFEST.json")
for p in [C/"C_FINAL_COMPACT.json",C/"C_DECISIVE_CERT_EVIDENCE.json.gz",C/"C_EXPORT_MANIFEST.json",C/"C_ALL_ARTIFACTS.zip"]:
    print(p.name,p.stat().st_size,sha(p))
print(json.dumps({"cert":compact["certification"],"replication":compact["replication"],"direct":direct_summaries}))

