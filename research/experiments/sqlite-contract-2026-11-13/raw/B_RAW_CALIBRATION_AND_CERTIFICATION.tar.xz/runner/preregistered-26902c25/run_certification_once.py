#!/usr/bin/env python3
"""Execution wrapper for the frozen, separately preregistered 28 trials.
No protocol or runner mutation; refuses a second start in this location.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/Users/murphyhoops/Documents/ueot-sqlite-study-20261113')
DEPLOY = ROOT / 'runner/preregistered-26902c25'
PYTHON = '/Library/Developer/CommandLineTools/usr/bin/python3'
EXPECTED = {
    'sqlite_study.py': 'bdbe87252da0b107602f7e30509b4b094f53d97a647ac9dc34cb378195dd92d9',
    'protocol.json': 'f68c5e9b643738563eebdce032bf13126e63036b2b473f889840355af5e00566',
    'CERTIFICATION_AUTHORIZATION.json': '0dcd48bcb1cc55d6d595cfe6f721f9fd5b5bce3225e72f7c4dd352914bb1831a',
    'RUN_ALLOCATION.json': '2561677d933aec2ceef8ca3a80a6d480a5cebc32a55a99a0dbdfeb63f6e66b02',
    'README.md': '2da9b70042ae648bd1926018930ff5b72ffe60d463f74fb7e1586a8394e389f0',
    'PREREGISTRATION.md': '73cb2d621c9012207db24c74edb4087232d1cff1f4375f511de6061e2562d349',
}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

files = {}
for name, expected in EXPECTED.items():
    path = DEPLOY / name
    observed = digest(path)
    if observed != expected:
        raise RuntimeError('Deployment hash mismatch: ' + name)
    files[name] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': observed}
authorization = json.loads((DEPLOY / 'CERTIFICATION_AUTHORIZATION.json').read_text())
if authorization['preregistration_commit'] != '26902c25152ca3676b4844d2156f028145f62fe2':
    raise RuntimeError('Unexpected preregistration')
allocation = json.loads((DEPLOY / 'RUN_ALLOCATION.json').read_text())['certification']
if len(allocation) != 28:
    raise RuntimeError('Unexpected allocation size')
directory = ROOT / 'certification'
directory.mkdir(parents=True, exist_ok=True)
output = directory / 'run-v1'
if output.exists():
    raise RuntimeError('Certification output already exists; do not repeat')
command = [PYTHON, str(DEPLOY / 'sqlite_study.py'), 'run', '--split', 'certification',
           '--protocol', str(DEPLOY / 'protocol.json'), '--out', str(output),
           '--authorization', str(DEPLOY / 'CERTIFICATION_AUTHORIZATION.json')]
start = {'started_utc': now(), 'wrapper_pid': os.getpid(), 'argv': command,
         'deployed_files': files, 'authorization': authorization,
         'expected_trials': 28, 'scope': 'B certification only; no calibration or replication'}
write_new(directory / 'v1-controller-start.json', start)
with (directory / 'v1-controller.stdout.log').open('xb') as stdout:
    with (directory / 'v1-controller.stderr.log').open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, check=False)
receipt = dict(start)
receipt.update(finished_utc=now(), subprocess_returncode=result.returncode)
for name in ['SUMMARY.json', 'RUNS_PLANNED.json', 'RUN_MANIFEST.json', 'FILE_MANIFEST.json']:
    path = output / name
    receipt[name] = {'exists': path.exists()}
    if path.exists():
        receipt[name].update(bytes=path.stat().st_size, sha256=digest(path))
receipt['allocation_matches_frozen'] = (
    json.loads((output / 'RUNS_PLANNED.json').read_text()) == allocation
) if (output / 'RUNS_PLANNED.json').exists() else False
receipt['deployed_files_unchanged'] = all(digest(DEPLOY / n) == h for n, h in EXPECTED.items())
summary = json.loads((output / 'SUMMARY.json').read_text()) if (output / 'SUMMARY.json').exists() else {}
receipt['summary_counts'] = {key: summary.get(key) for key in [
    'planned', 'attempted', 'complete', 'execution_errors', 'not_run', 'candidate_baseline_disagreements']}
for name in ['v1-controller.stdout.log', 'v1-controller.stderr.log']:
    path = directory / name
    receipt[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
write_new(directory / 'v1-controller-receipt.json', receipt)
print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)
if result.returncode != 0:
    sys.exit(result.returncode)
if not receipt['allocation_matches_frozen'] or not receipt['deployed_files_unchanged']:
    sys.exit(3)
